<table border="1">
    <thead>
        <tr>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">No.</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Nis</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Nisn</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Nama</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Jenis Kelamin (1. Laki - Laki, 2 Perempuan)</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">ID Kelas</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Alamat</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Tanggal Lahir (Y-m-d)</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">No Telpon</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Nama Wali</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Angkatan</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Agama</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">Pin</td>
            <td style="background-color:#E78F5E; text-align:center; vertical-align:center;">ID jurusan</td>
        </tr>
    </thead>
    <tbody>
    </tbody>
</table>
